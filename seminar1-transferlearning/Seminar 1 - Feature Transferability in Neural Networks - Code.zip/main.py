import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset
import numpy as np
import matplotlib.pyplot as plt
import copy
import time

# Set random seed for reproducibility
torch.manual_seed(42)
np.random.seed(42)

# Configuration
BATCH_SIZE = 64
NUM_WORKERS = 2
LEARNING_RATE = 0.001
MOMENTUM = 0.9
WEIGHT_DECAY = 0.0005
NUM_EPOCHS = 20
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")


# Custom CNN architecture
class TransferNet(nn.Module):
    def __init__(self, num_classes=5):
        super(TransferNet, self).__init__()

        # Use ModuleList for easier layer transfer
        self.features = nn.ModuleList([
            # Layer 1: Conv + ReLU + MaxPool
            nn.Sequential(
                nn.Conv2d(3, 32, kernel_size=3, padding=1),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2, stride=2)
            ),
            # Layer 2: Conv + ReLU + MaxPool
            nn.Sequential(
                nn.Conv2d(32, 64, kernel_size=3, padding=1),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2, stride=2)
            ),
            # Layer 3: Conv + ReLU + MaxPool
            nn.Sequential(
                nn.Conv2d(64, 128, kernel_size=3, padding=1),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2, stride=2)
            )
        ])

        self.classifier = nn.ModuleList([
            # Layer 4: FC + ReLU
            nn.Sequential(
                nn.Linear(128 * 4 * 4, 256),
                nn.ReLU(inplace=True),
                nn.Dropout(0.5)
            ),
            # Layer 5: FC (output)
            nn.Sequential(
                nn.Linear(256, num_classes)
            )
        ])

    def forward(self, x):
        # Pass through feature layers
        for layer in self.features:
            x = layer(x)

        # Flatten
        x = x.view(x.size(0), -1)

        # Pass through classifier layers
        for layer in self.classifier:
            x = layer(x)

        return x


def create_cifar_splits():
    """
    Create two non-overlapping splits of CIFAR-10 with 5 classes each.
    """
    # Data transformations
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # Load the CIFAR-10 dataset
    train_dataset = torchvision.datasets.CIFAR10(
        root='./data',
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.CIFAR10(
        root='./data',
        train=False,
        download=True,
        transform=transform
    )

    # Define class splits (0-4 for A, 5-9 for B)
    classes_A = set(range(5))  # airplane, automobile, bird, cat, deer
    classes_B = set(range(5, 10))  # dog, frog, horse, ship, truck

    # Create indices for dataset A and B
    train_indices_A = [i for i, (_, label) in enumerate(train_dataset) if label in classes_A]
    train_indices_B = [i for i, (_, label) in enumerate(train_dataset) if label in classes_B]

    test_indices_A = [i for i, (_, label) in enumerate(test_dataset) if label in classes_A]
    test_indices_B = [i for i, (_, label) in enumerate(test_dataset) if label in classes_B]

    # Create subset datasets
    train_dataset_A = Subset(train_dataset, train_indices_A)
    train_dataset_B = Subset(train_dataset, train_indices_B)

    test_dataset_A = Subset(test_dataset, test_indices_A)
    test_dataset_B = Subset(test_dataset, test_indices_B)

    # Create dataloaders
    train_loader_A = DataLoader(
        train_dataset_A,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS
    )

    train_loader_B = DataLoader(
        train_dataset_B,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS
    )

    test_loader_A = DataLoader(
        test_dataset_A,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS
    )

    test_loader_B = DataLoader(
        test_dataset_B,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS
    )

    # Create label mapping for each split (0-4 → 0-4 for A, 5-9 → 0-4 for B)
    # This is needed because our network is designed for 5 classes
    def remap_targets_A(batch):
        images, targets = batch
        # No need to remap A, they're already 0-4
        return images, targets

    def remap_targets_B(batch):
        images, targets = batch
        # Remap B labels from 5-9 to 0-4
        targets = targets - 5
        return images, targets

    return {
        'A': {
            'train': train_loader_A,
            'test': test_loader_A,
            'remap_fn': remap_targets_A
        },
        'B': {
            'train': train_loader_B,
            'test': test_loader_B,
            'remap_fn': remap_targets_B
        }
    }


def train_model(model, dataloader, remap_fn, criterion, optimizer, num_epochs):
    """
    Train the given model.
    """
    model.to(DEVICE)
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0

    start_time = time.time()

    for epoch in range(num_epochs):
        print(f'Epoch {epoch + 1}/{num_epochs}')
        print('-' * 10)

        # Training phase
        model.train()
        running_loss = 0.0
        running_corrects = 0
        total_samples = 0

        # Iterate over data
        for batch in dataloader:
            inputs, labels = remap_fn(batch)
            inputs = inputs.to(DEVICE)
            labels = labels.to(DEVICE)

            # Zero the parameter gradients
            optimizer.zero_grad()

            # Forward pass
            with torch.set_grad_enabled(True):
                outputs = model(inputs)
                _, preds = torch.max(outputs, 1)
                loss = criterion(outputs, labels)

                # Backward pass and optimize
                loss.backward()
                optimizer.step()

            # Statistics
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)
            total_samples += inputs.size(0)

        epoch_loss = running_loss / total_samples
        epoch_acc = running_corrects.double() / total_samples

        print(f'Training Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')

        # Save best model
        if epoch_acc > best_acc:
            best_acc = epoch_acc
            best_model_wts = copy.deepcopy(model.state_dict())

    time_elapsed = time.time() - start_time
    print(f'Training completed in {time_elapsed // 60:.0f}m {time_elapsed % 60:.0f}s')
    print(f'Best training accuracy: {best_acc:.4f}')

    # Load best model weights
    model.load_state_dict(best_model_wts)
    return model


def evaluate_model(model, dataloader, remap_fn):
    """
    Evaluate the model on the given test data.
    """
    model.eval()
    running_corrects = 0
    total_samples = 0

    # Iterate over data
    with torch.no_grad():
        for batch in dataloader:
            inputs, labels = remap_fn(batch)
            inputs = inputs.to(DEVICE)
            labels = labels.to(DEVICE)

            # Forward pass
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)

            # Statistics
            running_corrects += torch.sum(preds == labels.data)
            total_samples += inputs.size(0)

    acc = running_corrects.double() / total_samples
    return acc.item()


def create_transfer_network(source_model, target_model, n_layers, freeze=True):
    """
    Create a transfer network by copying the first n layers from source to target.
    If freeze=True, the transferred layers will not be updated during training.
    """
    # Determine how many conv layers and fc layers to copy
    conv_layers = len(source_model.features)
    fc_layers = len(source_model.classifier)
    total_layers = conv_layers + fc_layers

    # Check that n_layers is valid
    if n_layers < 0 or n_layers > total_layers:
        raise ValueError(f"n_layers must be between 0 and {total_layers}")

    # Copy conv layers
    conv_to_copy = min(n_layers, conv_layers)
    if conv_to_copy > 0:
        for i in range(conv_to_copy):
            target_model.features[i].load_state_dict(source_model.features[i].state_dict())

            # Freeze if requested
            if freeze:
                for param in target_model.features[i].parameters():
                    param.requires_grad = False

    # Copy fc layers if needed
    fc_to_copy = max(0, n_layers - conv_layers)
    if fc_to_copy > 0:
        for i in range(fc_to_copy):
            target_model.classifier[i].load_state_dict(source_model.classifier[i].state_dict())

            # Freeze if requested
            if freeze:
                for param in target_model.classifier[i].parameters():
                    param.requires_grad = False

    return target_model


def run_yosinski_experiment():
    """
    Run a simplified version of the Yosinski experiment.
    """
    print("Starting Yosinski experiment...")

    # Create datasets A and B
    datasets = create_cifar_splits()
    print("Datasets created.")

    # Initialize criterion
    criterion = nn.CrossEntropyLoss()

    # Train base networks
    print("\nTraining baseA network...")
    baseA = TransferNet(num_classes=5)
    optimizer = optim.Adam(baseA.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    baseA = train_model(
        baseA,
        datasets['A']['train'],
        datasets['A']['remap_fn'],
        criterion,
        optimizer,
        NUM_EPOCHS
    )

    print("\nTraining baseB network...")
    baseB = TransferNet(num_classes=5)
    optimizer = optim.Adam(baseB.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    baseB = train_model(
        baseB,
        datasets['B']['train'],
        datasets['B']['remap_fn'],
        criterion,
        optimizer,
        NUM_EPOCHS
    )

    # Evaluate base networks
    baseA_acc = evaluate_model(baseA, datasets['A']['test'], datasets['A']['remap_fn'])
    baseB_acc = evaluate_model(baseB, datasets['B']['test'], datasets['B']['remap_fn'])
    print(f"\nBase network accuracies: A={baseA_acc:.4f}, B={baseB_acc:.4f}")

    # Define the layers to test (we'll test fewer layers to save time)
    # Our network has 5 layers total: 3 conv and 2 fc
    layers = [1, 2, 3, 4]  # Test first 4 layers

    # Initialize results dictionaries
    results = {
        'baseB_acc': baseB_acc,
        'BnB_frozen_acc': [],
        'BnB_finetuned_acc': [],
        'AnB_frozen_acc': [],
        'AnB_finetuned_acc': []
    }

    # Run experiments for each layer
    for n in layers:
        print(f"\nExperiment for layer {n}")

        # Create selffer network with frozen layers (BnB)
        print("Training BnB (selffer with frozen layers)...")
        BnB_frozen = create_transfer_network(baseB, TransferNet(num_classes=5), n, freeze=True)
        # Only train unfrozen parameters
        optimizer = optim.Adam(
            [p for p in BnB_frozen.parameters() if p.requires_grad],
            lr=LEARNING_RATE,
            weight_decay=WEIGHT_DECAY
        )
        BnB_frozen = train_model(
            BnB_frozen,
            datasets['B']['train'],
            datasets['B']['remap_fn'],
            criterion,
            optimizer,
            NUM_EPOCHS
        )
        BnB_frozen_acc = evaluate_model(BnB_frozen, datasets['B']['test'], datasets['B']['remap_fn'])
        results['BnB_frozen_acc'].append(BnB_frozen_acc)

        # Create selffer network with fine-tuning (BnB+)
        print("Training BnB+ (selffer with fine-tuning)...")
        BnB_finetuned = create_transfer_network(baseB, TransferNet(num_classes=5), n, freeze=False)
        optimizer = optim.Adam(
            BnB_finetuned.parameters(),
            lr=LEARNING_RATE,
            weight_decay=WEIGHT_DECAY
        )
        BnB_finetuned = train_model(
            BnB_finetuned,
            datasets['B']['train'],
            datasets['B']['remap_fn'],
            criterion,
            optimizer,
            NUM_EPOCHS
        )
        BnB_finetuned_acc = evaluate_model(BnB_finetuned, datasets['B']['test'], datasets['B']['remap_fn'])
        results['BnB_finetuned_acc'].append(BnB_finetuned_acc)

        # Create transfer network with frozen layers (AnB)
        print("Training AnB (transfer with frozen layers)...")
        AnB_frozen = create_transfer_network(baseA, TransferNet(num_classes=5), n, freeze=True)
        optimizer = optim.Adam(
            [p for p in AnB_frozen.parameters() if p.requires_grad],
            lr=LEARNING_RATE,
            weight_decay=WEIGHT_DECAY
        )
        AnB_frozen = train_model(
            AnB_frozen,
            datasets['B']['train'],
            datasets['B']['remap_fn'],
            criterion,
            optimizer,
            NUM_EPOCHS
        )
        AnB_frozen_acc = evaluate_model(AnB_frozen, datasets['B']['test'], datasets['B']['remap_fn'])
        results['AnB_frozen_acc'].append(AnB_frozen_acc)

        # Create transfer network with fine-tuning (AnB+)
        print("Training AnB+ (transfer with fine-tuning)...")
        AnB_finetuned = create_transfer_network(baseA, TransferNet(num_classes=5), n, freeze=False)
        optimizer = optim.Adam(
            AnB_finetuned.parameters(),
            lr=LEARNING_RATE,
            weight_decay=WEIGHT_DECAY
        )
        AnB_finetuned = train_model(
            AnB_finetuned,
            datasets['B']['train'],
            datasets['B']['remap_fn'],
            criterion,
            optimizer,
            NUM_EPOCHS
        )
        AnB_finetuned_acc = evaluate_model(AnB_finetuned, datasets['B']['test'], datasets['B']['remap_fn'])
        results['AnB_finetuned_acc'].append(AnB_finetuned_acc)

        # Print layer results
        print(f"\nResults for layer {n}:")
        print(f"BnB (frozen): {BnB_frozen_acc:.4f}")
        print(f"BnB+ (fine-tuned): {BnB_finetuned_acc:.4f}")
        print(f"AnB (frozen): {AnB_frozen_acc:.4f}")
        print(f"AnB+ (fine-tuned): {AnB_finetuned_acc:.4f}")

    # Plot results
    plt.figure(figsize=(10, 6))
    plt.plot(layers, results['BnB_frozen_acc'], 'bo-', label='selffer BnB (frozen)')
    plt.plot(layers, results['BnB_finetuned_acc'], 'b^-', label='selffer BnB+ (fine-tuned)', alpha=0.7)
    plt.plot(layers, results['AnB_frozen_acc'], 'ro-', label='transfer AnB (frozen)')
    plt.plot(layers, results['AnB_finetuned_acc'], 'r^-', label='transfer AnB+ (fine-tuned)', alpha=0.7)
    plt.axhline(y=results['baseB_acc'], color='k', linestyle='--', label='baseB')

    plt.xlabel('Layer n at which network is chopped and retrained')
    plt.ylabel('Accuracy on test set')
    plt.title('Transferability of features at different layers')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.xticks(layers)
    plt.savefig('transferability_results.png')
    plt.show()

    return results


if __name__ == "__main__":
    results = run_yosinski_experiment()
    print("Final results:", results)